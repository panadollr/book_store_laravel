<br>
  <div class="ui inverted vertical footer segment" id="footer" >
  <div class="ui container">
    <div class="ui stackable inverted divided equal height stackable grid">
      <div class="three wide column">
        <h4 class="ui inverted header">Thông tin</h4>
        <div class="ui inverted link list">
          <a href="#" class="item">Chính sách bảo mật</a>
          <a href="#" class="item">Điều khoản</a>
          <a href="#" class="item">Liên hệ với</a>
        </div>
      </div>
      <div class="three wide column">
        <h4 class="ui inverted header">Chăm sóc khách hàng</h4>
        <div class="ui inverted link list">
          <a href="" class="item">Trung tâm trợ giúp</a>
          <a href="#" class="item">DNA FAQ</a>
          <a href="#" class="item">Hướng dẫn mua hàng</a>
        </div>
      </div>
      <div class="seven wide column">
        <h4 class="ui inverted header">Thanh toán</h4>
        <img src="https://cdn.vhost.vn/wp-content/uploads/2017/05/ho-tro-thanh-toan-qua-the-ngan-hang-vhost.jpg" class="ui image">
      </div>
    </div>
  </div>
</div>

<script src="{{ asset('assets/jquery.min.js') }}" ></script>
<script src="{{ asset('assets/semantic.min.js') }}"></script>

<script>
   function hideHeaderSegment(){
$('.masthead').css({
    'min-height': '0px',
    'background': '#1b1c1d'
  });
  $('.masthead .ui.text.container').hide()
    }

    var currentUrl = window.location.href;
    if(!currentUrl.includes('trangchu')){
      hideHeaderSegment() 
    }

    // Iterate through each menu item
$('.menu .item').each(function() {
  // Get the href attribute of the current menu item
  var href = $(this).attr('href');
  
  // Compare the currentUrl with the href
  if (currentUrl === href) {
    // Add a class to mark the item as active
    $(this).addClass('active');
  }
});
    
 $(document)
    .ready(function() {

      $('.ui.sidebar')
        .sidebar('attach events', '.toc.item');

    });

    $('#giohang').popup();

function successAlert(msg){
  $('body')
  .toast({
     class: 'success',
    message: msg,
  });
}

function errorAlert(msg){
  $('body')
  .toast({
     class: 'error',
    message: msg,
  });
}

</script>


@if(\Session::has('success'))
<script >
  successAlert('{{\Session::get('success') }}');
  </script>
@endif

@if(\Session::has('error'))
<script >
 errorAlert('{{\Session::get('error') }}')
  </script>
@endif