@include('user.layouts.header')

<div class="ui container">

<form class="ui large form" style="padding:70px" method="POST" action="{{url('xacthucdangnhap')}}">
@csrf
  <h1 class="ui dividing header">Đăng nhập</h1>
  <div class="field">
    <label>Email</label>
        <input type="email" name="email" required/>
      </div>
      <div class="field">
    <label>Mật khẩu</label>
        <input type="password" name="password" required/>
      </div>
 <center> <button class="ui large blue button" >Đăng nhập</button>
<a href="{{url('dangky')}}">Chưa có tài khoản ?</a>
</center>
</form>
</div>

@if ($errors->any())
<div class="ui negative message">
  <div class="header">Đăng nhập thất bại</div>
  <ul class="list">
    @foreach ($errors->all() as $error)
      <li>{{ $error }}</li>
    @endforeach
  </ul>
</div>
@endif

@include('user.layouts.footer')