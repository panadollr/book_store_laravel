@include('user.layouts.header')

<style>
  .ui.cards .card{
    box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.2);
  }
</style>

<body>


<h1 class="ui center aligned header">Sách mới nhất</h1>
<div class="ui six stackable special cards" style="padding:60px;margin-top: -60px">
@foreach($lastest_books as $book)
  <a class="card" href="{{ url('chitietsach/'.$book->id)}}">
      <div class="ui move down instant reveal image">
      <img src="{{$book->book_image}}" class="visible content" style="object-fit: cover;height: 350px;">
        <div class="hidden center aligned content" style="background:white;height:100%;padding:10px">
        <br><br><br>  
          <h3 class="ui black header">{{Str::limit($book->book_title,70)}}</h3>
          <h3 class="ui blue header"> {{number_format($book->book_price)}} đ </h3>
        </div>
</div>
  </a>
  @endforeach
</div>

<hr>

<h1 class="ui center aligned header">Sách bán chạy nhất</h1>
@if(count($sellest_books) > 0)
<div class="ui six stackable special cards" style="padding:60px;margin-top: -60px">
@foreach($sellest_books as $book)
  <a class="card" href="{{ url('chitietsach/'.$book->id)}}">
      <div class="ui move up instant reveal image">
      <img src="{{$book->book_image}}" class="visible content" style="object-fit: cover;height: 350px;">
        <div class="hidden center aligned content" style="background:white;height:100%;padding:10px">
        <br><br><br>  
          <h3 class="ui black header" s>{{Str::limit($book->book_title,70)}}</h3>
          <h3 class="ui blue header"> {{number_format($book->book_price)}} đ </h3>
          <h4 class="ui black header">Đã bán: {{$book->quantity}}</h4>
        </div>
</div>
  </a>
  @endforeach
</div>
@else
<h3 class="ui center aligned header" style="padding:60px">Chưa có sản phẩm !</h3>
@endif

        </body>
</html>


@include('user.layouts.footer')


