 <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <title>Table</title>

 <div class="pusher" style="margin-right: 400px;">
   
 <table class="ui celled padded table" style="text-align:center;" >
    <br>
    <h1 class="ui center aligned header">Liệt kê đơn hàng</h1>
  <thead>
    <tr><th class="single line">Mã đơn hàng</th>
    <th class="single line">Tên người đặt</th>
    <th>Tổng tiền(VNĐ)</th>
    <th>Tình trạng</th>
     <th>Xem chi tiết</th>
     <th>Tùy chỉnh</th>
    
  </tr></thead>
  <tbody>
    <?php $__currentLoopData = $allbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr >
       <td >
     <a ><?php echo e($book->order_id); ?></a>
      </td>
      <td >
     <a name="publisherid"><?php echo e($book->shipping_name); ?></a>
      </td>
      <td >
     <h4 class="ui center aligned header"><?php echo e($book->order_total); ?></h4>
      </td>
        <td> 

<?php if($book->order_status =='Đang chờ xác nhận' || $book->order_status =='Đang giao hàng'): ?> 
<br>         
<div class="ui blue sliding indeterminate progress" id="progress">
    <div class="bar">
        <div class="progress" ><?php echo e($book->order_status); ?>...</div>
    </div>
</div>
<?php endif; ?>

<?php if($book->order_status =='Đã giao hàng'): ?>          
<div  class="ui large green label" id="successorder">
   <?php echo e($book->order_status); ?></div>
<?php endif; ?>

<h3 id="complete_order" style="color:green;display: none"><?php echo e($book->order_status); ?></h3>
</td>
        <td><a style="display: none;" href="<?php echo e(URL::to('/view_order/'.$book->order_id)); ?>" class="ui blue button">Xem chi tiết</a>
            <button class="ui blue button" id="detail_order" data-order_id="<?php echo e($book->order_id); ?>">Xem chi tiết</button>
        </td>
       <td>
        <?php if($book->order_status =='Đang chờ xác nhận'): ?>  
        <a id="check_order" href="<?php echo e(URL::to('/delivery_order/'.$book->payment_id)); ?>" class="ui green button">Xác nhận và giao  hàng</a>
        <?php endif; ?>


<?php if($book->order_status =='Đang giao hàng'): ?>     
        
<a class="ui green button" href="<?php echo e(URL::to('/complete_order/'.$book->order_id)); ?>">Duyệt đơn hàng</a>
        <?php endif; ?>


       </td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
 
</table></div>

<script type="text/javascript">
    document.getElementById('a2').className='active item';
</script>

 <script type="text/javascript">
  
 $(document).on('click','#detail_order',function(){
    var order_id = $(this).data('order_id'); 
     $.ajax({
      url:"<?php echo e(url('/detail_order_ajax')); ?>", 
      method:"GET", 
      data:{order_id:order_id},
      success:function(data){ 
        $('#detail_order_form').html(data);
        $('.ui.modal').modal('show');
;
     }
   });
   
 });

  </script>

  <div class="ui large modal" id="detail_order_form">
</div><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/admin/order_manager.blade.php ENDPATH**/ ?>