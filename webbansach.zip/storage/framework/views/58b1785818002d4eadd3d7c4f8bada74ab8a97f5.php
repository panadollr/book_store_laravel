<script>
document
    .getElementById("addToCartForm")
    .addEventListener("submit", function (e) {
        e.preventDefault();

        // Retrieve form data
        const quantity = document.querySelector(
            '#addToCartForm input[name="quantity"]'
        ).value;

        // Perform AJAX request
        fetch("<?php echo e(URL::to(" / save_cart / ".$bookdetail->id)); ?>", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
            },
            body: JSON.stringify({
                quantity: quantity,
            }),
        })
            .then((response) => response.json())
            .then((data) => {
                $("#book_details-segment")
                    .css({ transition: "0.5s" })
                    .css({
                        transform:
                            " translateY(-95%) translateX(-27%) scale(0.1)",
                    })
                    .css({ opacity: "0" });

                setTimeout(() => {
                    $("#book_details-segment")
                        .css({ transition: "0s" })
                        .css({ transform: " translateY(50%) translateX(0)" });
                    document.querySelector("#giohang .label").textContent =
                        data.length;
                    $("#giohang").transition("pulse");
                }, 400);

                setTimeout(() => {
                    $("#book_details-segment")
                        .css({ transition: "0.5s" })
                        .css({ transform: " translateY(0) translateX(0)" })
                        .css({ opacity: "1" });
                }, 600);

                let html = `<table style='width:400px' class='ui celled table' >
  <thead >
    <tr><th class='right marked blue'>Sản phẩm</th>
    <th class='right marked blue'>Số lượng</th>
    <th class='right marked blue'>Giá tiền</th>
  </tr></thead>
  <tbody>`;
                data.forEach((cart) => {
                    const formattedPrice = Number(
                        cart.book_price
                    ).toLocaleString("vi-VN", {
                        style: "currency",
                        currency: "VND",
                    });
                    html += `<tr>
      <td style='font-weight:bold;color:#2185d0;'>${cart.book_name}</td>
      <td style='font-weight:bold;color:#2185d0;'>${cart.book_amount}</td>
      <td  style='font-weight:bold;width:100px;color:#2185d0 '>${formattedPrice}</td>
    </tr>`;
                });
                html += `</tbody>
</table>`;

                document
                    .querySelector("#giohang")
                    .setAttribute("data-html", html);
            });
    });

document.getElementById("commentForm").addEventListener("submit", function (e) {
    e.preventDefault();

    // Retrieve form data
    const commentContentTextarea = document.querySelector(
        '#commentForm textarea[name="comment_content"]'
    );
    const ratingInput = document.querySelector(
        '#commentForm input[name="rating"]'
    );
    const rating = ratingInput.value;
    const commentContent = commentContentTextarea.value;
    const userName = document.querySelector(
        '#commentForm input[name="user_name"]'
    ).value;

    // Perform AJAX request
    fetch("<?php echo e(URL::to(" / dangbinhluan / ".$bookdetail->id)); ?>", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
        },
        body: JSON.stringify({
            rating: rating,
            comment_content: commentContent,
        }),
    })
        .then((response) => response.json())
        .then((data) => {
            // Handle response from the server
            const commentDate = data.comment_date;
            let stars = "";
            for (let i = 0; i < rating; i++) {
                stars += '<i class="yellow star icon"></i>';
            }
            const commentsElement = document.getElementById("comments");
            const html = `<div class="comment">
    <a class="avatar">
    <i class="user big outline icon"></i>
    </a>
    <div class="content">
      <a class="author">${userName}</a>
      <div class="metadata">
      <span class="date">${commentDate}</span>
      ${stars}
      
      </div>
      <div class="text">
        <p>${commentContent}</p>
      </div>
    </div>
 </div>`;
            commentsElement.insertAdjacentHTML("afterbegin", html);
            document
                .getElementById("comments-segment")
                .scrollIntoView({ behavior: "smooth", block: "start" });
            commentContentTextarea.value = "";
            var noCommentsDiv = document.getElementById("no_comments_text");
            if (noCommentsDiv) {
                noCommentsDiv.style.display = "none";
            }
            $(".ui.rating").rating("clear rating", true);
            successAlert("Đăng bình luận thành công !");
        })
        .catch((error) => {
            errorAlert("Lỗi, đăng bình luận không thành công !");
        });
});

$(".rating").rating({
    initialRating: 0,
    maxRating: 5,
});

const rateTextArr = ["Rất tệ", "Tệ", "Ổn", "Tốt", "Rất tốt"];
for (let i = 1; i <= $(".rating").children().length; i++) {
    $(".rating i:nth-child(" + i + ")").click(function () {
        $("#comm input[name*='rating']").val(i);
        $("#rate_text").text(rateTextArr[i - 1]);
    });
}

</script><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/custom.blade.php ENDPATH**/ ?>