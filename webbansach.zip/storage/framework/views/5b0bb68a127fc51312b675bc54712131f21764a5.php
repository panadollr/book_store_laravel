<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
  .ui.cards .card{
    box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.2);
  }
</style>

<body>


<h1 class="ui center aligned header">Sách mới nhất</h1>
<div class="ui six stackable special cards" style="padding:60px;margin-top: -60px">
<?php $__currentLoopData = $lastest_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a class="card" href="<?php echo e(url('chitietsach/'.$book->id)); ?>">
      <div class="ui move down instant reveal image">
      <img src="<?php echo e($book->book_image); ?>" class="visible content" style="object-fit: cover;height: 350px;">
        <div class="hidden center aligned content" style="background:white;height:100%;padding:10px">
        <br><br><br>  
          <h3 class="ui black header"><?php echo e(Str::limit($book->book_title,70)); ?></h3>
          <h3 class="ui blue header"> <?php echo e(number_format($book->book_price)); ?> đ </h3>
        </div>
</div>
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<hr>

<h1 class="ui center aligned header">Sách bán chạy nhất</h1>
<?php if(count($sellest_books) > 0): ?>
<div class="ui six stackable special cards" style="padding:60px;margin-top: -60px">
<?php $__currentLoopData = $sellest_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <a class="card" href="<?php echo e(url('chitietsach/'.$book->id)); ?>">
      <div class="ui move up instant reveal image">
      <img src="<?php echo e($book->book_image); ?>" class="visible content" style="object-fit: cover;height: 350px;">
        <div class="hidden center aligned content" style="background:white;height:100%;padding:10px">
        <br><br><br>  
          <h3 class="ui black header" s><?php echo e(Str::limit($book->book_title,70)); ?></h3>
          <h3 class="ui blue header"> <?php echo e(number_format($book->book_price)); ?> đ </h3>
          <h4 class="ui black header">Đã bán: <?php echo e($book->quantity); ?></h4>
        </div>
</div>
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php else: ?>
<h3 class="ui center aligned header" style="padding:60px">Chưa có sản phẩm !</h3>
<?php endif; ?>

        </body>
</html>


<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/index.blade.php ENDPATH**/ ?>