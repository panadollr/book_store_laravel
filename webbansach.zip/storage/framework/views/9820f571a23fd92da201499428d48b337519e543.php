 <script src="https://cdn.jsdelivr.net/npm/jquery@3.3.1/dist/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/fomantic-ui@2.8.8/dist/semantic.min.css">
<script src="https://cdn.jsdelivr.net/npm/fomantic-ui@2.8.8/dist/semantic.min.js"></script>
  <body>
   
  <style type="text/css">
    body{
      font-size: 2.2ch;
      background: #DCDCDC;
    }
  </style>
 <div class="ui left demo visible vertical inverted blue sidebar labeled icon menu" >
  <a id="all" href="<?php echo e(URL::to('admin/tong_quan')); ?>" class="item">
  <i class="user shield icon"></i>
    Tổng quan
  </a>
 <a id="a0" href="<?php echo e(URL::to('admin/publishers')); ?>" class="item">
    <i class="block layout icon"></i>
    Bảng nhà xuất bản
  </a>

  <a id="a1" href="<?php echo e(URL::to('admin/books')); ?>" class="item">
    <i class="book open icon"></i>
    Bảng sản phẩm
  </a>
  <a id="a2" href="<?php echo e(URL::to('admin/orders')); ?>" class="item">
      <i class="clipboard icon"></i>
    Đơn hàng
  </a>
  <a id="a5" href="<?php echo e(URL::to('admin/comments')); ?>" class="item">
  <i class="comments icon"></i>
    Bình luận
  </a>
  <a id="a4" class="item" href="<?php echo e(URL::to('/admin/logout')); ?>" >
  <i class="sign out alternate icon"></i>đăng xuất</a>
</div>
</body>

 <?php if(\Session::has('success')): ?>
<script >
   $('body')
  .toast({
     class: 'success',
    message: ' <?php echo e(\Session::get('success')); ?>',
  });
  </script>
<?php endif; ?>

 <?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script > 
   $('body')
  .toast({
     class: 'error',
    message: '<?php echo e($error); ?>',
    showProgress: 'bottom',
  })
;
  </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>