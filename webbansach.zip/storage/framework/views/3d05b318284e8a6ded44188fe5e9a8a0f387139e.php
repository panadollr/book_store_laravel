
<!DOCTYPE html>
<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/semantic.min.css')); ?>" >
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/fomantic-ui@2.9.2/dist/semantic.min.css">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title><?php echo e(config('app.name')); ?></title>

  <style type="text/css">
  :root{
--primary-color: #F8F8FF;
--secondary-color: #004687;
--font-color: black;
--button-color: white;
  }
  .dark-theme{
--primary-color: #1b1c1d;
--secondary-color: white;
--font-color: white;
--button-color: black;
  }

  body{
   background:var(--primary-color);
}

    .hidden.menu {
      display: none;
    }

    .masthead.segment {
      min-height: 200px;
      padding: 1em 0em;
    }
    .masthead .logo.item img {
      margin-right: 1em;
    }
    .masthead .ui.menu .ui.button {
      margin-left: 0.5em;
    }
    .masthead h1.ui.header {
      margin-top: 0.2em;
      margin-bottom: 0em;
      font-size: 3em;
      font-weight: normal;
    }
    .masthead h2 {
      font-size: 1.7em;
      font-weight: normal;
    }

    .ui.vertical.stripe {
      padding: 8em 0em;
    }
    .ui.vertical.stripe h3 {
      font-size: 2em;
    }
    .ui.vertical.stripe .button + h3,
    .ui.vertical.stripe p + h3 {
      margin-top: 3em;
    }
    .ui.vertical.stripe .floated.image {
      clear: both;
    }
    .ui.vertical.stripe p {
      font-size: 1.33em;
    }
    .ui.vertical.stripe .horizontal.divider {
      margin: 3em 0em;
    }

    .quote.stripe.segment {
      padding: 0em;
    }
    .quote.stripe.segment .grid .column {
      padding-top: 5em;
      padding-bottom: 5em;
    }

    .footer.segment {
      padding: 5em 0em;
    }

    .secondary.pointing.menu .toc.item {
      display: none;
    }

    @media only screen and (max-width: 700px) {
      .ui.fixed.menu {
        display: none !important;
      }
      .secondary.pointing.menu .item,
      .secondary.pointing.menu .menu {
        display: none;
      }
      .secondary.pointing.menu .toc.item {
        display: block;
      }
      .masthead.segment {
        min-height: 350px;
      }
      .masthead h1.ui.header {
        font-size: 2em;
        margin-top: 1.5em;
      }
      .masthead h2 {
        margin-top: 0.5em;
        font-size: 1.5em;
      }
    }

  </style>
</head>


<!-- Sidebar Menu -->
<div class="ui vertical inverted sidebar menu">
  <a class="item" href="<?php echo e(url('/trangchu')); ?>">Trang chủ</a>
  <a class="item" href="<?php echo e(url('/khosach')); ?>">Kho sách</a>
  <a class="item">Giỏ hàng</a>
  <a class="item">Đăng nhập</a>
  <a class="item">Đăng ký</a>
</div>


<!-- Page Contents -->
<div class="pusher">
  <div style="background: url(<?php echo e(asset('images/banner.jpg')); ?>);background-size: cover;
  background-position: center;" class="ui inverted vertical masthead center aligned segment">

    <div class="ui container">
      <div class="ui large secondary inverted pointing menu">
        <a class="toc item">
          <i class="sidebar icon"></i>
        </a>
        <a class="item" href="<?php echo e(url('/trangchu')); ?>">Trang chủ</a>
  <a class="item" href="<?php echo e(url('/khosach')); ?>">Kho sách</a>
  <a class="item" href="<?php echo e(url('/show_cart')); ?>" id="giohang" data-html="<?php $carts=Session::get('cart') ?>
            <?php if($carts): ?>
              <table style='width:400px' class='ui celled table' >
  <thead >
    <tr><th class='right marked blue'>Sản phẩm</th>
    <th class='right marked blue'>Số lượng</th>
    <th class='right marked blue'>Giá tiền</th>
  </tr></thead>
  <tbody>
  <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td style='font-weight:bold;color:#2185d0;'><?php echo e(Str::limit($cart['book_name'],40)); ?></td>
      <td style='font-weight:bold;color:#2185d0;'><?php echo e($cart['book_amount']); ?></td>
      <td  style='font-weight:bold;width:100px;color:#2185d0 '><?php echo e(number_format($cart['book_price'])); ?> đ</td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
            <?php else: ?> Chưa có sản phẩm ! <?php endif; ?>">Giỏ hàng <div class="ui red label">
              <?php if($carts): ?> <?php echo e(count($carts)); ?> <?php else: ?> 0 <?php endif; ?> </div>
            </a>       

<a href="<?php echo e(url('timkiem')); ?>" class="item">Tìm kiếm</a>

        <div class="right item">
        <?php $user = Session::get('user'); ?>
                       <?php if($user): ?>
                            

<div class="ui small compact menu" style="background: var(--button-color);">
  <div class="ui simple inline dropdown item" style="color:var(--font-color);font-size: 1.8ch;font-weight: bold;">
    <i class="user icon"></i>
      <?php echo e($user->name); ?>                              
    <i class="dropdown icon"></i>
    <div class="menu" >
       <a class="item"  href="<?php echo e(url('/donhang')); ?>">Đơn hàng của bạn</a>
      <a class="item" href="<?php echo e(url('cai_dat_tai_khoan')); ?>">Cài đặt tài khoản</a>
     <a class="item"  href="<?php echo e(url('dangxuat')); ?>"> Đăng xuất</a>
    </div>
  </div>
</div>                        

<?php else: ?>
          <a class="ui inverted button" href="<?php echo e(url('dangnhap')); ?>">Đăng nhập</a>
          <a class="ui inverted button" href="<?php echo e(url('dangky')); ?>">Đăng ký</a>
<?php endif; ?>
        </div>
      </div>
    </div>

    <div class="ui text container">
      <h1 class="ui inverted header">
        Cửa hàng kinh doanh sách online
      </h1>
      <h2>Tri thức cho lập trình viên</h2>
    </div>


  </div>


</html>
<?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/layouts/header.blade.php ENDPATH**/ ?>