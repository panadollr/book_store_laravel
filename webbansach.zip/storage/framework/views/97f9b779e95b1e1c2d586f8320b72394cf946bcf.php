<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php
$user = Session::get('user');
?>

<br>
<div class="ui container">
    <h2 class="ui center aligned header">Cài đặt tài khoản</h2>

   <div class="ui segment">
   <form class="ui form">
  <div class="field">
    <label>Tên tài khoản
    </label>
    <input type="text" name="name" value="<?php echo e($user->name); ?>" placeholder="<?php echo e($user->name); ?>">
  </div>
  <div class="field">
    <label>Email</label>
    <input disabled placeholder="<?php echo e($user->email); ?>" value="<?php echo e($user->email); ?>">
  </div>
  <div class="field">
  </div>
  <button class="ui button" type="submit">Cập nhật</button>
</form>
   </div>

</div>

<br><br><br><br>
<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/user_account_settings.blade.php ENDPATH**/ ?>