<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<div class="ui container">
    <h2 class="ui center aligned header">Đơn hàng của bạn</h2>

    <div id="order_status_menu" class="ui blue three item menu">
  <a href="<?php echo e(url('donhang')); ?>" class="item">Đang chờ xác nhận</a>
  <a href="<?php echo e(url('donhang?status=danggiaohang')); ?>" class="item">Đang giao hàng</a>
  <a href="<?php echo e(url('donhang?status=dagiaohang')); ?>" class="item">Đã giao hàng</a>
</div>


<script>
  var currentUrl = window.location.href;
var menuItems = document.querySelectorAll('#order_status_menu .item');
for (var i = 0; i < menuItems.length; i++) {
  var menuItemUrl = menuItems[i].getAttribute('href');
  if (currentUrl == menuItemUrl) {
    menuItems[i].classList.add('active');
  }
}
</script>


<?php if(count($user_orders) > 0): ?>
<div class="ui list">
<?php $__currentLoopData = $user_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="ui item segment" style="background:white;padding: 10px; margin-top:20px;border-radius:20px;
  box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.2);">
    <div class="content">

    <div class="ui large relaxed divided list">
    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($order->order_id == $order_detail->order_id): ?>
  <div class="item">
  <img class="ui middle aligned tiny image" src="<?php echo e($order_detail->book_image); ?>">
    <div class="content">
      <div class="header"><?php echo e($order_detail->product_name); ?></div>
      <h4><?php echo e(number_format($order_detail->product_price)); ?> đ</h4>
      <div class="description">Số lượng : <?php echo e($order_detail->product_sales_quantity); ?></div>
    </div>
  </div>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

      <!-- <h4 class="ui label header">Mã đơn hàng <?php echo e($order->order_id); ?> <span class="right floated container">Thời gian đặt hàng : <?php echo e($order->date); ?></span></h4>
      
      <div class="ui divided items">
        <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($order->order_id == $order_detail->order_id): ?>
  <div class="item">
    <div class="image">
      <img style="width:100px" src="<?php echo e($order_detail->book_image); ?>">
    </div>
    <div class="content">
      <div class="header"><?php echo e($order_detail->product_name); ?></div>
      <div class="meta">
        <h3><?php echo e(number_format($order_detail->product_price)); ?> đ</h3>
        <span class="stay">Số lượng : <?php echo e($order_detail->product_sales_quantity); ?></span>
      </div>
      <div class="description">
        <p></p>
      </div>
    </div>
  </div>
  <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> -->


<div class="right floated container">
<h3>Tổng tiền : <?php echo e(number_format($order->order_total)); ?> đ</h3>
<?php if($order->order_status == 'Đang chờ xác nhận'): ?>
<a href="<?php echo e(url('/xoadonhang/'.$order->payment_id)); ?>" class="ui red button">
          Hủy đơn hàng
          <i class="right trash icon"></i>
        </a>
        <?php endif; ?>
        </div>

    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<h3 style="padding:60px" class="ui center aligned header">Chưa có đơn hàng nào !</h3>
<?php endif; ?>
</div>

</div>

<br>
<script>
    $('#kiemtradonhang').addClass('active')
</script>

<br>
<br>
<br>
<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/user_order.blade.php ENDPATH**/ ?>