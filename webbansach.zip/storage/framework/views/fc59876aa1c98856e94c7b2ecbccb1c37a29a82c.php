  <?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php $total=0; ?>

  <br><br>
      <h1 class="ui center aligned header" style="color:var(--font-color)">Giỏ hàng</h1>
  <script type="text/javascript">
document.getElementById("giohang").className = "active item";
</script>


    <?php if($carts): ?>
    <div class="ui segment">
  <div class="ui two column stackable grid">
    <div class="column" style="width:70%">
    
    <table class="ui large table">
  <thead>
    <tr><th>Sản phẩm</th>
    <th>Hình ảnh</th>
    <th>Số lượng</th>
    <th>Giá tiền</th>
    <th>Thành tiền</th>
    <th colspan="2">Tùy chỉnh</th>
  </tr></thead>
  <tbody>
    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $total+=$cart['book_price']*$cart['book_amount'] ?>
    <tr id="cart<?php echo e($key); ?>">
      <td><?php echo e(Str::limit($cart['book_name'],100)); ?></td>
      <td><img style="width:100px" class="ui rounded image" src="<?php echo e($cart['book_image']); ?>" alt="" srcset=""></td>
      <!-- <td>
        <form action="<?php echo e(URL::to('/update_cart_quantity/'.$key)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="ui input" style="width:80px">
        <input name="cart_quantity" min=0 max=10 type="number" value="<?php echo e($cart['book_amount']); ?>">
        </div>
      </td> -->

      <td><?php echo e(number_format($cart['book_price'])); ?> đ</td>

      <td>
  <div class="ui labeled input">
  <button class="ui icon button" onclick="subtract('<?php echo e($key); ?>')"><i class="minus icon"></i></button>
  <div class="ui input" style="width:45px">
  <input disabled id="cart_quantity<?php echo e($key); ?>" value="<?php echo e($cart['book_amount']); ?>">
</div>
  <button onclick="plus('<?php echo e($key); ?>')" style="margin-left: 3px" class="ui icon button"><i class="plus icon"></i></button>
  </div>
</td>

      <td id="total"><?php echo e(number_format($cart['book_price'] * $cart['book_amount'])); ?> đ</td>
      <td><a onclick="deleteCart('<?php echo e($key); ?>')" class="ui red button">Xóa</a></td>
</form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

    </div>
    <div class="middle aligned column" style="width: 30%">
    
 <center>  
 <h1 class="ui blue header" id="all_total">Tổng tiền: <?php echo e(number_format((float)$total,0,',','.')); ?></h1>

  <div class="ui large buttons">
  <a href="<?php echo e(url('/khosach')); ?>"><button class="ui button" style="background:#DCDCDC;" id="demo" >Tiếp tục mua sắm</button></a>
  <div class="or" data-text=""></div>
  <a href="<?php echo e(URL::to('/checkout')); ?>"><button class="ui blue button">Tiến hành thanh toán</button></a>
</div>
</center>

    </div>
  </div>
</div>
<?php else: ?>
<h1 style="padding:105px;" class="ui center aligned header">Không có sản phẩm !</h1>
    <?php endif; ?>


    
<script type="text/javascript">
function xoa(){
  $('#xoa')
  .modal('setting', 'closable', false)
  .modal('show');
}

function plus(book_id){
  const cartQuantityInput = document.getElementById('cart_quantity' + book_id);
let quantity = parseInt(cartQuantityInput.value) + 1;
cartQuantityInput.value = quantity
updateCartQuantity(book_id,quantity)
}

function subtract(book_id){
  const cartQuantityInput = document.getElementById('cart_quantity' + book_id);
let quantity = parseInt(cartQuantityInput.value) - 1;
cartQuantityInput.value = quantity;
updateCartQuantity(book_id,quantity)
}

function deleteCart(key){
  updateCartQuantity(key,0)
}

function updateCartQuantity(key, quantity){
    fetch("<?php echo e(URL::to('/update_cart_quantity')); ?>/"+key, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      },
      body: JSON.stringify({
        cart_quantity : quantity
      })
    })
    .then(response => response.json())
    .then(data => {
      if(data.all_carts.length == 0){
        $('#cart'+key).transition('fade') 
        successAlert('Đã xóa sản phẩm !')
      }else{
        $('#cart'+key).transition('pulse') 
        const formattedPrice = Number(data.cart.book_price * data.cart.book_amount).toLocaleString('vi-VN', {
  style: 'currency',
  currency: 'VND'
});
        $('#cart' + key + ' #total').text(formattedPrice) 
        let all_total = 0;
        data.all_carts.forEach((cart) => {
  all_total += cart.book_price * cart.book_amount;
});
        const formattedTotal = Number(all_total).toLocaleString('vi-VN', {
  style: 'currency',
  currency: 'VND'
});
$('#all_total').text('Tổng tiền: ' + formattedTotal) 
        successAlert('Đã cập nhật sản phẩm !')
      }
    })
    .catch(error => {
      errorAlert("Lỗi !");
    });
}

</script>

<br>
 <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/show_cart.blade.php ENDPATH**/ ?>