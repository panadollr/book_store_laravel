<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <br><br>
<div class="ui container" style="margin-top:30px;">

<div class="ui two column very relaxed stackable grid">
    <div class="column" style="width: 60%;background: white;padding: 15px;border-radius: 20px;">
    
<div class="ui divided items">
  <div class="item">
  
    <div id="main" class="ui image" >
      <img style="height: 400px" src="<?php echo e(asset($bookdetail->book_image)); ?>"  >   
    </div>
    <div class="content">
    <h4 class="ui block header" ><?php echo e($bookdetail->book_title); ?></h4>
      <div class="meta">
        <p>Tác giả : <?php echo e($bookdetail->book_author); ?></p>
         <div class="ui large blue label"><?php echo e(number_format($bookdetail->book_price)); ?> đ</div>
          <div class="extra">
        <div class="ui right floated ">
          <form method="POST" action="<?php echo e(URL::to('/save_cart')); ?>">
            <?php echo csrf_field(); ?>
           <div class="ui labeled input"><div class="ui label" >
   Số lượng
  </div> <input type="number" name="quantity" value="1" min="1" max="20"></div>

            <input type="hidden" name="book_id" value="<?php echo e($bookdetail->id); ?>">
           <button name="cart" class="ui blue button" type="submit">Thêm vào giỏ hàng <i class="right cart icon"></i></button>
          </form>
        </div>
      
      </div>
      </div>
    </div>
  </div>
</div>
  <div class="description"> 
<div class="ui list">
  <div class="item">
    <div class="header" >Mô tả sách</div>
    <h4 class="ui block header" style="font-weight:lighter;"><?php echo e($bookdetail->book_descr); ?></h4>
  </div><br>
</div> 
      </div>

<center>

<div class="ui blue inverted segment">
 <div class="ui comments" style="text-align: left;" >
  <h3 class="ui inverted dividing header">Bình luận</h3>
  <div id="comments">
  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="comment" style="background: white;padding: 7px;border-radius: 10px;">
    <a class="avatar">
    <i class="user big outline icon"></i>
    </a>
    <div class="content">
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($user->id == $comment->user_id): ?>
      <a class="author"><?php echo e($user->name); ?></a>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="metadata">
      <span class="date" style="color:black"><?php echo e($comment->comment_date); ?></span>
      <?php 
      $tr=$comment->comment_rating;
      ?>
     <?php for($count=0;$count<$tr;$count++): ?>
       <i class="yellow star icon"></i>
<?php endfor; ?>
      </div>
      <div class="text">
        <p><?php echo e($comment->comment_content); ?></p>
      </div>
    </div>
    <?php $__currentLoopData = $reply_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$com_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($com_reply->comment_id ==$comment->comment_id): ?>
     <div class="comments">
        <div class="comment">
          <a class="avatar">
          <i class="user big circle icon"></i>
          </a>
          <div class="content">
            <a class="author"><?php echo e(config('app.name')); ?></a>
            <i class="check circle blue icon"></i>
            <div class="metadata">
      <span class="date" style="color:black"><?php echo e($com_reply->date); ?></span>
      </div>
            <div class="text">
              <?php echo e($com_reply->reply_comment_content); ?>

            </div>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>


  <form id="commentForm" class="ui reply form">
  <?php echo csrf_field(); ?>
  <div class="field" id="comm">
    <h4>Bạn đánh giá sản phẩm này bao nhiêu sao ?</h4>
    <div style="background:white; padding: 7px;border-radius:20px" class="ui massive yellow rating"></div>
    <span id="rate_text" style="font-weight: bold;font-size: 18px;"></span>
    <input type="hidden" name="rating" value="1">
    <?php if(Session::get('user')): ?>
    <input type="hidden" name="user_name" value="<?php echo e(Session::get('user')->name); ?>">
    <?php endif; ?>
    <br><br>
    <textarea name="comment_content" style="margin-top: 5px;" class="comment_content" required></textarea>
  </div>
  <center>
    <button type="submit" class="ui right labeled submit icon button send-comment">
      <i class="icon edit"></i> Bình luận
    </button>
  </center>
</form>

<script>
  document.getElementById('commentForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Retrieve form data
    const rating = document.querySelector('#commentForm input[name="rating"]').value;
    const commentContent = document.querySelector('#commentForm textarea[name="comment_content"]').value;
    const userName = document.querySelector('#commentForm input[name="user_name"]').value;

    // Perform AJAX request
    fetch('<?php echo e(URL::to('/dangbinhluan/'.$bookdetail->id)); ?>', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
      },
      body: JSON.stringify({
        rating: rating,
        comment_content: commentContent
      })
    })
    .then(response => response.json())
    .then(data => {
      // Handle response from the server
      const commentDate = data.comment_date;
      let stars = '';
for (let i = 0; i < rating; i++) {
    stars += '<i class="yellow star icon"></i>';
}
      const html = `<div class="comment" style="background: white;padding: 7px;border-radius: 10px;">
    <a class="avatar">
    <i class="user big outline icon"></i>
    </a>
    <div class="content">
      <a class="author">${userName}</a>
      <div class="metadata">
      <span class="date" style="color:black">${commentDate}</span>
      ${stars}
      
      </div>
      <div class="text">
        <p>${commentContent}</p>
      </div>
    </div>
 </div>`
      document.getElementById('comments').innerHTML += html;
      successAlert("Đăng bình luận thành công !");
    })
    .catch(error => {
      errorAlert("Lỗi, đăng bình luận không thành công !");
    });
  });

  $('.rating').rating({
    initialRating: 0,
    maxRating: 5
  });

  const rateTextArr = ['Rất tệ', 'Tệ', 'Ổn', 'Tốt', 'Rất tốt'];
  for (let i = 1; i <= $('.rating').children().length; i++) {
    $('.rating i:nth-child(' + i + ')').click(function() {
      $("#comm input[name*='rating']").val(i);
      $('#rate_text').text(rateTextArr[i - 1]);
    });
  }
</script>


</div>
</div>
</center>
    </div>
    <div class=" column" style="width:40%;margin-top: -13px;" >
      <div class="ui center aligned container" style="background: white;padding:20px;border-radius:20px;" >
      <h3 class="ui center aligned header">Các sách liên quan khác</h3>  
 

<div class="ui horizontal tiny cards" >
   <?php $__currentLoopData = $relative_books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div id="card" class="card" >
    <div class="image" >
      <img id="card_img" src="<?php echo e(asset($book->book_image)); ?>">
    </div>
    <div class="ui center aligned content" >
      <div class="header"> <?php echo e(Str::limit($book->book_title,55)); ?><br>
   
    <p><?php echo e(number_format($book->book_price)); ?>đ</p>
      </div>
      <div class="description">
        <a id="card_button"  href="<?php echo e(url('chitietsach/'.$book->id)); ?>" class="ui blue button">Xem chi tiết </a>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

      </div>
    </div>
  </div>

</div>

</div>
<script>
   document.getElementById("sach").className = "active item";
</script>


<?php if(\Session::has('success_comment')): ?>
<script >
 document.getElementById("comm").scrollIntoView();
  setTimeout(()=>{
$('#topfixednag')
.nag({
  persist:true
})
;
},500)

  </script>
<?php endif; ?>


 <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/book_details1.blade.php ENDPATH**/ ?>