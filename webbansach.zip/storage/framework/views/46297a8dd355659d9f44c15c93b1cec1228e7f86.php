 <?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="ui container" id="thongbao">
<h1 style="margin-top: 100px;font-size: 4ch;" class="ui center aligned header">Cảm ơn bạn đã mua hàng !</h1>

<h1 class="ui center aligned header" >



</h1><br>
<center> <a href="<?php echo e(url('/khosach')); ?>" class="ui blue button">Tiếp tục mua hàng</a></center>     
 </div>

<div style="height:80px"></div>
 <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/checkout/complete_payment.blade.php ENDPATH**/ ?>