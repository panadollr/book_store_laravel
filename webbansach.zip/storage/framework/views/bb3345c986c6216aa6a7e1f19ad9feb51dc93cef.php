<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<br>
<div class="ui container">
    <h2 class="ui center aligned header">Cài đặt tài khoản</h2>

   

</div>

<br>
<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/user_info.blade.php ENDPATH**/ ?>