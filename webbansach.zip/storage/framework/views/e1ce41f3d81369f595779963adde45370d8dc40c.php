<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="ui container">

<form class="ui large form" style="padding:70px" method="POST" action="<?php echo e(url('xacthucdangnhap')); ?>">
<?php echo csrf_field(); ?>
  <h1 class="ui dividing header">Đăng nhập</h1>
  <div class="field">
    <label>Email</label>
        <input type="email" name="email" required/>
      </div>
      <div class="field">
    <label>Mật khẩu</label>
        <input type="password" name="password" required/>
      </div>
 <center> <button class="ui large blue button" >Đăng nhập</button>
<a href="<?php echo e(url('dangky')); ?>">Chưa có tài khoản ?</a>
</center>
</form>
</div>

<?php if($errors->any()): ?>
<div class="ui negative message">
  <div class="header">Đăng nhập thất bại</div>
  <ul class="list">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

<?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/user/login.blade.php ENDPATH**/ ?>