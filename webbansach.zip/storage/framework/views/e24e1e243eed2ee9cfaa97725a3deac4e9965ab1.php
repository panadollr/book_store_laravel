 <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <title>Bình luận</title>
 <br>
 <div class="pusher" style="margin-right: 400px;">
   
 <table class="ui celled padded table" style="text-align:center" >
    <h1 class="ui center aligned header">Duyệt và trả lời bình luận</h1>
  <thead>
    <tr>
    <th class="single line">Tên người gửi</th>
    <th>Bình luận</th>
    <th>Đánh giá sao</th>
    <th>Ngày gửi</th>
     <th>Mã sản phẩm</th>
     <th>Tùy chỉnh</th>
    
  </tr></thead>
  <tbody>
    <?php $__currentLoopData = $allcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    
      <td >
     <a name="publisherid"><?php echo e($comm->user_id); ?></a>
      </td>

 <td> <br>
     <h4 class="ui center aligned header" style="margin-top: -20px"><?php echo e($comm->comment_content); ?></h4>
       <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$com_reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($com_reply->comment_id ==$comm->comment_id): ?>
    <li><?php echo e($com_reply->reply_comment_content); ?><a href="<?php echo e(URL::to('/xoaphanhoi/'.$com_reply->reply_comment_id)); ?>"><i style="margin-left:5px;color: #db2828;" class="trash alternate icon"></i></a></li>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br>
    
     <form action="<?php echo e(URL::to('traloibinhluan')); ?>" method="POST">
         <?php echo csrf_field(); ?>
         <input type="hidden" name="comment_id" value="<?php echo e($comm->comment_id); ?>">
          <textarea style="height:50px" name="reply_comment_content"></textarea>
     <br><br>
     <button class="ui small blue button" type="submit">Trả lời bình luận</button>
     </form>
      </td>

        <td>
             <?php 
      $tr=$comm->comment_rating;
      ?>
     <?php for($count=0;$count<$tr;$count++): ?>
       <i class="star icon" style="color:orange;font-size:1.4ch"></i>
<?php endfor; ?>
        </td>
      <td >
          <h4><?php echo e($comm->comment_date); ?></h4>
      </td>
       <td>
          <h4><?php echo e($comm->id); ?></h4>
      </td>
      <td>
          <a style="width:130px" href="<?php echo e(URL::to('/xoabinhluan/'.$comm->comment_id)); ?>" class="ui small red button">Xóa bình luận</a>
      </td>
    </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>

  <tfoot>
  <tr>
    <th colspan="6">
      <div class="ui right floated pagination menu">
        <?php if($allcomments->currentPage() > 1): ?>
          <a href="<?php echo e($allcomments->previousPageUrl()); ?>" class="item">
            <i class="left chevron icon"></i>
          </a>
        <?php endif; ?>

        <?php for($i = 1; $i <= $allcomments->lastPage(); $i++): ?>
          <a href="<?php echo e($allcomments->url($i)); ?>" class="item<?php echo e($allcomments->currentPage() == $i ? ' active' : ''); ?>">
            <?php echo e($i); ?>

          </a>
        <?php endfor; ?>

        <?php if($allcomments->hasMorePages()): ?>
          <a href="<?php echo e($allcomments->nextPageUrl()); ?>" class="item">
            <i class="right chevron icon"></i>
          </a>
        <?php endif; ?>
      </div>
    </th>
  </tr>
</tfoot>
</table></div>

<script type="text/javascript">
    document.getElementById('a5').className='active item';
</script><?php /**PATH F:\xampp\htdocs\webbansach\resources\views/admin/comments.blade.php ENDPATH**/ ?>